<?php
       //Incluir a conexao
       include("conexao.php");

       //Obter dados
       //$obterDados = file_get_contents('php://input');

       $json_convertido =  json_decode(file_get_contents('php://input'), true);
   
       //Extrair os dados do JSON
       //$extrair = json_decode($json_convertido);
       
       
       //Separar os dados do JSON
       $idCurso = $json_convertido->cusos->idCurso;
       
    

    //sql
    $sql = "DELETE FROM cursos WHERE idCurso = $idCurso";
    mysqli_query($conexao, $sql);


?>